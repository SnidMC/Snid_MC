import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const commands = await db.minecraftCommand.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    })
    
    return NextResponse.json(commands)
  } catch (error) {
    console.error('Erro ao buscar comandos:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar comandos' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, command, description, category, version, author } = body

    if (!title || !command || !category) {
      return NextResponse.json(
        { error: 'Título, comando e categoria são obrigatórios' },
        { status: 400 }
      )
    }

    const newCommand = await db.minecraftCommand.create({
      data: {
        title,
        command,
        description,
        category,
        version,
        author
      }
    })

    return NextResponse.json(newCommand, { status: 201 })
  } catch (error) {
    console.error('Erro ao criar comando:', error)
    return NextResponse.json(
      { error: 'Erro ao criar comando' },
      { status: 500 }
    )
  }
}