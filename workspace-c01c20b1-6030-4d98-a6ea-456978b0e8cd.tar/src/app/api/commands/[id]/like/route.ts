import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    const command = await db.minecraftCommand.update({
      where: { id },
      data: {
        likes: {
          increment: 1
        }
      }
    })

    return NextResponse.json(command)
  } catch (error) {
    console.error('Erro ao curtir comando:', error)
    return NextResponse.json(
      { error: 'Erro ao curtir comando' },
      { status: 500 }
    )
  }
}