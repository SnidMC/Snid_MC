'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Search, Plus, Copy, Heart, Command, Code, BookOpen } from 'lucide-react'
import { toast } from 'sonner'

interface MinecraftCommand {
  id: string
  title: string
  command: string
  description?: string
  category: string
  version?: string
  author?: string
  likes: number
  createdAt: string
}

const categories = [
  'Geral',
  'Administração',
  'Construção',
  'Sobrevivência',
  'Multijogador',
  'Mundo',
  'Itens',
  'Entidades',
  'Redstone',
  'Personalização'
]

export default function Home() {
  const [commands, setCommands] = useState<MinecraftCommand[]>([])
  const [filteredCommands, setFilteredCommands] = useState<MinecraftCommand[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  
  const [newCommand, setNewCommand] = useState({
    title: '',
    command: '',
    description: '',
    category: '',
    version: '',
    author: ''
  })

  useEffect(() => {
    fetchCommands()
  }, [])

  useEffect(() => {
    filterCommands()
  }, [commands, searchTerm, selectedCategory])

  const fetchCommands = async () => {
    try {
      const response = await fetch('/api/commands')
      if (response.ok) {
        const data = await response.json()
        setCommands(data)
      }
    } catch (error) {
      console.error('Erro ao buscar comandos:', error)
    }
  }

  const filterCommands = () => {
    let filtered = commands

    if (searchTerm) {
      filtered = filtered.filter(cmd => 
        cmd.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cmd.command.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cmd.description?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(cmd => cmd.category === selectedCategory)
    }

    setFilteredCommands(filtered)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch('/api/commands', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newCommand),
      })

      if (response.ok) {
        toast.success('Comando adicionado com sucesso!')
        setNewCommand({
          title: '',
          command: '',
          description: '',
          category: '',
          version: '',
          author: ''
        })
        setIsDialogOpen(false)
        fetchCommands()
      } else {
        toast.error('Erro ao adicionar comando')
      }
    } catch (error) {
      toast.error('Erro ao adicionar comando')
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = async (command: string) => {
    try {
      await navigator.clipboard.writeText(command)
      toast.success('Comando copiado para a área de transferência!')
    } catch (error) {
      toast.error('Erro ao copiar comando')
    }
  }

  const likeCommand = async (id: string) => {
    try {
      const response = await fetch(`/api/commands/${id}/like`, {
        method: 'POST',
      })

      if (response.ok) {
        fetchCommands()
        toast.success('Comando curtido!')
      }
    } catch (error) {
      toast.error('Erro ao curtir comando')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-green-950 dark:to-emerald-950">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
              <Command className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-green-800 dark:text-green-200">
              Minecraft Commands Hub
            </h1>
          </div>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Descubra, compartilhe e organize os melhores comandos do Minecraft para aprimorar sua experiência de jogo
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar comandos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as Categorias</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Comando
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Adicionar Novo Comando</DialogTitle>
                <DialogDescription>
                  Compartilhe um comando útil com a comunidade Minecraft
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    value={newCommand.title}
                    onChange={(e) => setNewCommand({...newCommand, title: e.target.value})}
                    placeholder="Ex: Teleport para spawn"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="command">Comando</Label>
                  <Textarea
                    id="command"
                    value={newCommand.command}
                    onChange={(e) => setNewCommand({...newCommand, command: e.target.value})}
                    placeholder="/tp @p 0 100 0"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={newCommand.description}
                    onChange={(e) => setNewCommand({...newCommand, description: e.target.value})}
                    placeholder="Descreva o que este comando faz..."
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Categoria</Label>
                    <Select value={newCommand.category} onValueChange={(value) => setNewCommand({...newCommand, category: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(category => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="version">Versão</Label>
                    <Input
                      id="version"
                      value={newCommand.version}
                      onChange={(e) => setNewCommand({...newCommand, version: e.target.value})}
                      placeholder="1.20.1"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="author">Autor</Label>
                  <Input
                    id="author"
                    value={newCommand.author}
                    onChange={(e) => setNewCommand({...newCommand, author: e.target.value})}
                    placeholder="Seu nome"
                  />
                </div>
                
                <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isLoading}>
                  {isLoading ? 'Adicionando...' : 'Adicionar Comando'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Commands Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCommands.map((cmd) => (
            <Card key={cmd.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg mb-2">{cmd.title}</CardTitle>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary">{cmd.category}</Badge>
                      {cmd.version && (
                        <Badge variant="outline">v{cmd.version}</Badge>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => likeCommand(cmd.id)}
                    className="text-red-500 hover:text-red-600"
                  >
                    <Heart className="w-4 h-4 mr-1" />
                    {cmd.likes}
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent>
                {cmd.description && (
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                    {cmd.description}
                  </p>
                )}
                
                <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-gray-500">COMANDO</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(cmd.command)}
                      className="h-6 px-2 text-xs"
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Copiar
                    </Button>
                  </div>
                  <code className="text-sm text-green-600 dark:text-green-400 font-mono break-all">
                    {cmd.command}
                  </code>
                </div>
                
                {cmd.author && (
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Por {cmd.author}</span>
                    <span>{new Date(cmd.createdAt).toLocaleDateString('pt-BR')}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCommands.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-600 dark:text-gray-300 mb-2">
              Nenhum comando encontrado
            </h3>
            <p className="text-gray-500 dark:text-gray-400">
              {searchTerm || selectedCategory !== 'all' 
                ? 'Tente ajustar sua busca ou filtros' 
                : 'Seja o primeiro a adicionar um comando!'}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}